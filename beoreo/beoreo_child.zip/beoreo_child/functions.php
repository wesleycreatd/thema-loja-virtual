<?php
/* Define THEME */
if (!defined('beoreo_URI_PATH')) define('beoreo_URI_PATH', get_template_directory_uri());
if (!defined('beoreo_ABS_PATH')) define('beoreo_ABS_PATH', get_template_directory());
if (!defined('beoreo_URI_PATH_FR')) define('beoreo_URI_PATH_FR', beoreo_URI_PATH.'/framework');
if (!defined('beoreo_ABS_PATH_FR')) define('beoreo_ABS_PATH_FR', beoreo_ABS_PATH.'/framework');
if (!defined('beoreo_URI_PATH_ADMIN')) define('beoreo_URI_PATH_ADMIN', beoreo_URI_PATH_FR.'/admin');
if (!defined('beoreo_ABS_PATH_ADMIN')) define('beoreo_ABS_PATH_ADMIN', beoreo_ABS_PATH_FR.'/admin');
