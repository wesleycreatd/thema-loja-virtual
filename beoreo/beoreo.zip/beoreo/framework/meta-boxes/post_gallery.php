<div id="tb-blog-metabox" class='tb_metabox'>
	<?php
	$this->text('post_gallery',
			'Ids image',
			'',
			__('Please input the id for your link. Ex: 1,2,3','beoreo')
	);
	?>
</div>
