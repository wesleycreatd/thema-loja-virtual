<div class='tb_metabox' style="display: none;">
	<div id="tb_video_setting">
	<?php
	$this->upload('post_video_url',
			'Video URL',
			__('Please upload the (MP4,WebM,Ogg) video file or enter url video from Youtube/Vimeo (http://youtu.be/ID)','beoreo')
	);
	?>
	</div>
</div>
