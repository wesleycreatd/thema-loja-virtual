<div id="tb_portfolio_metabox" class='tb-portfolio-metabox'>
	<?php
	$this->text('portfolio_video_url',
			'Video Url',
			'',
			__('Enter portfolio video url of post. EX: https://player.vimeo.com/video/1084537','beoreo')
	);
	
	?>
</div>
