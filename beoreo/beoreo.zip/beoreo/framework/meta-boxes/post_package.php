<div id="tb_package_metabox" class='tb-package-metabox'>
	<?php
	$this->text('package_price',
			'Price',
			'',
			__('Please enter price of post.','beoreo')
	);
	$this->text('package_per_time',
			'Per Time',
			'',
			__('Please enter per time of post.','beoreo')
	);
	
	?>
</div>
