	</div><!-- #wrap -->
	<?php wp_footer(); ?>
</body>