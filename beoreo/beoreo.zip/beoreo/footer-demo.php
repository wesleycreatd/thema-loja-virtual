	</div><!-- #wrap -->
	<div id="bt-backtop"><i class="fa fa-arrow-up"></i></div>
	<?php wp_footer(); ?>
</body>